unzip Interpreter.zip
cd Interpreter
make
cd ..
sudo cp -r Interpreter /etc
sudo cp Interpreter/hav /usr/bin
rm -r Interpreter 
rm Interpreter.zip
