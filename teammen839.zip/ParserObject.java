package havabol;

public class ParserObject {
	public Scanner scan;
	
	public ParserObject(Scanner scan) {
		this.scan = scan;
	}
}
